var sf_version = '2.10b';
var scan_date  = 'Tue Nov 28 04:08:02 2017';
var scan_seed  = '0x72d1e3fd';
var scan_ms    = 24634867;
