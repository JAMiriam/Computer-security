var child = [
  { 'dupe': false, 'type': 2, 'name': 'http://127.0.0.1:8000/', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': false, 'csens': true, 'child_cnt': 22, 'issue_cnt': [ 27, 0, 2, 2, 0 ], 'sig': 0xab0b3da1 }
];
