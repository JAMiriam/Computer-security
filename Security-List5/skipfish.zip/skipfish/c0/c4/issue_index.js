var issue = [
  { 'severity': 3, 'type': 40201, 'sid': '0', 'extra': 'https://bootswatch.com/3/united/bootstrap.min.css', 'fetched': true, 'code': 200, 'len': 937, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i0' },
  { 'severity': 2, 'type': 30501, 'sid': '0', 'extra': 'https://cdn2.iconfinder.com/data/icons/circle-icons-1/64/security-128.png', 'fetched': true, 'code': 200, 'len': 937, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'utf-8', 'dir': 'i1' }
];
