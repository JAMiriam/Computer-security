var issue = [
  { 'severity': 0, 'type': 10405, 'sid': '0', 'extra': '', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'dir': 'i0' }
];
