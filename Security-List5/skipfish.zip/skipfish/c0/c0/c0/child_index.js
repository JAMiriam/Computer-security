var child = [
  { 'dupe': false, 'type': 4, 'name': 'group', 'dir': 'c0', 'linked': 0, 'url': 'http://127.0.0.1:8000/admin/auth/group/', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 0, 0, 0 ], 'sig': 0xfff9979a },
  { 'dupe': true, 'type': 4, 'name': 'user', 'dir': 'c1', 'linked': 0, 'url': 'http://127.0.0.1:8000/admin/auth/user/', 'fetched': true, 'code': 302, 'len': 0, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'utf-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xfff9979a }
];
