var child = [
  { 'dupe': false, 'type': 4, 'name': 'admin', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/static/admin/', 'fetched': true, 'code': 404, 'len': 1635, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': true, 'csens': false, 'child_cnt': 3, 'issue_cnt': [ 10, 0, 0, 0, 0 ], 'sig': 0xd745f1b4 }
];
