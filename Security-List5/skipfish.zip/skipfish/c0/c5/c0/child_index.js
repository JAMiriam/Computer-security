var child = [
  { 'dupe': false, 'type': 4, 'name': 'css', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/static/admin/css/', 'fetched': true, 'code': 404, 'len': 1643, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'missing': true, 'csens': true, 'child_cnt': 2, 'issue_cnt': [ 7, 0, 0, 0, 0 ], 'sig': 0xdd096139 }
];
