var child = [
  { 'dupe': false, 'type': 4, 'name': 'base.css', 'dir': 'c0', 'linked': 2, 'url': 'http://127.0.0.1:8000/static/admin/css/base.css/', 'fetched': true, 'code': 200, 'len': 16066, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 0, 0, 0 ], 'sig': 0xfff99a74 },
  { 'dupe': false, 'type': 4, 'name': 'login.css', 'dir': 'c1', 'linked': 2, 'url': 'http://127.0.0.1:8000/static/admin/css/login.css/', 'fetched': true, 'code': 200, 'len': 1203, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 2, 0, 0, 0, 0 ], 'sig': 0xfff99a74 }
];
