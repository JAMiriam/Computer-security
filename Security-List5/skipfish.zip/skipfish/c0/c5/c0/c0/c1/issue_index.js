var issue = [
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 1203, 'decl_mime': 'text/css', 'sniff_mime': 'text/css', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10205, 'sid': '0', 'extra': '', 'fetched': true, 'code': 404, 'len': 1694, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': '[none]', 'dir': 'i1' }
];
